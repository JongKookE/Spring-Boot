package com.mycom.more;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMoreApplication.class, args);
	}

}
